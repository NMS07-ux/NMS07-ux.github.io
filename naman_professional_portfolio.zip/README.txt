Naman Portfolio — Professional Version

Files:
- index.html
- style.css

Before publishing:
1. Replace YOUR_EMAIL@example.com in index.html.
2. Replace the GitHub and LinkedIn links with your actual profiles.

Free GitHub Pages:
1. Create a PUBLIC GitHub repository named YOURUSERNAME.github.io
2. Upload index.html and style.css.
3. Settings > Pages > Deploy from a branch > main > Save.
4. Visit https://YOURUSERNAME.github.io/

The site uses Google Fonts via an external stylesheet. If you want a fully offline version, replace those fonts with system fonts.
